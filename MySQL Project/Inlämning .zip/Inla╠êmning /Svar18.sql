-- Ta bort en titel från tabellen titles. 
DELETE FROM titles
WHERE titleid = 8;


