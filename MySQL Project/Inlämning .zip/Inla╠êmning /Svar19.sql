-- Ta bort en skådespelare från tabellen actors. 
DELETE FROM actors
WHERE actorid = 15;

