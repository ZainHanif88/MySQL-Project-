-- Visa alla titlar i tabellen titles.

SELECT t.title
FROM Zainozon.titles t
