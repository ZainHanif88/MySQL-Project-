-- Uppdatera en befintlig titels utgivningsår i tabellen titles.
UPDATE titles
SET year = 2022
WHERE titleid = 8;
