-- Visa alla betyg i tabellen ratings.

SELECT r.rating
FROM Zainozon.ratings r