-- Lägg till en ny producent i tabellen producers
INSERT INTO producers (producername)
VALUES ('James Cameron');