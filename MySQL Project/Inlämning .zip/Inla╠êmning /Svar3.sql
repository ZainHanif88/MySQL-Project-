--  Visa alla skådespelare i tabellen actors.

SELECT a.actorname
FROM Zainozon.actors  a