--  Lägg till en ny skådespelare i tabellen actors.
INSERT INTO actors (actorname, gender)
VALUES ('Leonardo Dicaprio', 'Male');