-- Lägg till en ny producent till 
-- en befintlig titel i tabellen title_producers.
INSERT INTO title_producers (titleid, producerid)
VALUES ('8', '26');
