-- Lägg till ett nytt betyg i tabellen 
-- ratings för en specifik titel.
INSERT INTO ratings (titleid, rating)
VALUES ('8', '5');