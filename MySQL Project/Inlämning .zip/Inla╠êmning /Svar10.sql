-- Lägg till en ny titel i tabellen titles. 
SELECT * 
FROM Zainozon.titles;
INSERT INTO titles (title, year)
VALUES ('Titanic', '1997');
