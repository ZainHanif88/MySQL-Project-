-- Visa alla producenter i tabellen producers. 
SELECT p.producername 
FROM Zainozon.producers p;