-- Ta bort ett betyg från tabellen ratings.
DELETE FROM ratings
WHERE ratingid = 205;

