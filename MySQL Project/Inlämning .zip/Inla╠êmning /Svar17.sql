-- Uppdatera ett befintligt betyg i tabellen ratings. 
UPDATE ratings
SET rating = '1'
WHERE ratingid = 207;
