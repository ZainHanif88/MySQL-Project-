-- Ta bort en producent från tabellen producers. 
DELETE FROM producers
WHERE producerid = 24; 

